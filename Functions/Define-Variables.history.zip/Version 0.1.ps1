<#
		.SYNOPSIS
		Initializes module-level variables.

		.DESCRIPTION
		Internal module initialization script that defines and configures module-level variables including root server addresses and other module settings.
#>

# =============================================================================
# FUNCTION EXPORT CONTROL
# =============================================================================
# Set to $true to export the function, $false to keep it internal.
# If a function is not listed, it will be exported by default.
# NOTE: If this table is modified, regenerate DnsTools.psm1 and redeploy.
# =============================================================================

$script:FunctionExportTable = @{
    # User-facing functions (exported)
    'Resolve-DnsIterative'           = $true
    'Resolve-Dnssec'                 = $true
    'Resolve-DnssecChain'            = $true
    'Resolve-DnssecName'             = $true
    'Test-DnssecValidation'          = $true
    'Test-DnssecName'                = $true
    'Update-DnssecTrustAnchors'      = $true
    'Get-DnssecTrustAnchors'         = $true
    'Add-DnssecTrustAnchor'          = $true
    'Import-DnssecTrustAnchors'      = $true

    # Type/Class/Algorithm conversion functions (exported - useful for users)
    'ConvertTo-DnsTypeCode'          = $true
    'ConvertFrom-DnsTypeCode'        = $true
    'Format-DnsTypeName'             = $true
    'ConvertTo-DnsClassCode'         = $true
    'ConvertFrom-DnsClassCode'       = $true
    'Format-DnsClassName'            = $true
    'ConvertTo-DnssecAlgorithmCode'  = $true
    'ConvertFrom-DnssecAlgorithmCode'= $true
    'Format-DnssecAlgorithmName'     = $true

    # Wire format functions (exported - useful for advanced users)
    'ConvertFrom-DnsPacket'          = $true
    'New-DnsQueryPacket'             = $true
    'Invoke-DnsUdpQuery'             = $true

    # Internal helper functions (not exported)
    'Write-Trace'                    = $false
    'Resolve-NameserverAddress'      = $false
    'Invoke-DnsTransportSafe'        = $false
    'ConvertFrom-DnsWireBytes'       = $false
    'ConvertTo-DnsWireBytes'         = $false
    'ConvertTo-HexString'            = $false
    'ConvertFrom-DnsHeader'          = $false
    'ConvertFrom-DnsQuestion'        = $false
    'Get-RecordTypeA'                = $false
    'Get-RecordTypeAAAA'             = $false
    'Format-DnsIterativeResult'      = $false
    'Format-DnsResponse'             = $false
    'Format-DnssecResult'            = $false
    'Initialize-DnssecTrustAnchors'  = $false

    # Internal DNSSEC functions (not exported)
    'Get-DnssecCanonicalNameWire'    = $false
    'Get-DnssecCanonicalRrWire'      = $false
    'Get-DnssecCanonicalRrsetData'   = $false
    'Get-DnssecSignedData'           = $false
    'Get-DnssecKeyDigest'            = $false
    'Get-DnssecKeyDigestHex'         = $false
    'Get-DnssecNsec3Hash'            = $false
    'Get-DnssecSigningKey'           = $false
    'Test-DnssecTimeWindow'          = $false
    'Test-DnssecRrsig'               = $false
    'Test-DnssecDsForDnskey'         = $false
    'Test-DnssecChain'               = $false
    'Test-DnssecNsec3Nodata'         = $false
    'Test-DnssecNsec3Nxdomain'       = $false
    'Test-DnssecNsec3OptOut'         = $false
    'Find-DnssecNsec3ClosestEncloser'= $false
    'Find-DnssecNsec3NextCloser'     = $false
    'Test-DnssecAnchoredDnskey'      = $false
    'Test-DnssecSignature'           = $false
    'ConvertTo-ReverseDnsName'       = $false
}

# In the following tables defining variables:
#
# Option can be one of the following: AllScope, Private, Constant, ReadOnly, None
# Scope  can be one of the following: Global, Local, Script , Using, Workflow
# See Microsoft documentation for full descriptions.
#
# To use the regular expressions below:
#
# Does the item your testing match the expresion:
#
# if (($RegexComment.Match($Item).Success)){'It is a comment'}else{'It is not a comment'}
#
# To get the item itself use the name defined in the expression:
#
# $Result = $RegexFile.Match($Item)
# $Length = $Result.Groups['file'].length - will return the length of the 'file' group
# $Entry = $Result.Groups['file'].value - will return the value of the 'file' group
#
# Alternativly you can use:
#
# If ($Item -match $RegexFile)
# {$matches['file']} # to display the item if a match is found
#
# Both ways return different attributes it depends how you want to use the results
#
# NOTE: To get the captured group information the name is case sensitive.
#'file' is OK but 'File' is not!
#
# Add variables that you can use later in the 'MyConstantVars' hash table
#
# Variables defined in the 'MyOtherVars' hashtable can make use of the variables defined above
# in the 'MyConstantVars' or 'MyReadOnlyVars' hashtable
#
# NOTE: If any variables are defined in 'MyConstantVars' you will not be able to force a
# reload of the module, you will have to start a new PowerShell session.
#
# The option on the constant Variables is reda only to make testing easier
#
$MyVars = [Ordered]@{
	N00ConstantVars = @{
		VOConstant = @{
			Value  = 'Constant'
			Scope  = 'Script'
			Option = 'ReadOnly'
		}
		VSScript   = @{
			Value  = 'Script'
			Scope  = 'Script'
			Option = 'ReadOnly'
		}
		VOReadOnly = @{
			Value  = 'ReadOnly'
			Scope  = 'Script'
			Option = 'ReadOnly'
		}
	}
}
Publish-Variables
$MyVars = [Ordered]@{
	N00ConstantVars = @{
		VInfoOn    = @{
			Value  = $False
			Scope  = $VSScript
			Option = $VOReadOnly
			Use    = 'Define Variables Information'
		}
		FInfoOn    = @{
			Value  = $false
			Scope  = $VSScript
			Option = $VOReadOnly
			Use    = 'Define Common Functions Information'
		}
		FWInfoOn   = @{
			Value  = $false
			Scope  = $VSScript
			Option = $VOReadOnly
			Use    = 'Define Windows Functions Information'
		}
		FLInfoOn   = @{
			Value  = $False
			Scope  = $VSScript
			Option = $VOReadOnly
			Use    = 'Define Linux Functions Information'
		}
		FMInfoOn   = @{
			Value  = $False
			Scope  = $VSScript
			Option = $VOReadOnly
			Use    = 'Define MacOS Functions Information'
		}
	}
}
Publish-Variables
$MyVars = @{
	N01ReadOnlyVars = @{
		VSGlobal   = @{
			Value  = 'Global'
			Scope  = $VSScript
			Option = $VOReadOnly
		}
		VSUsing    = @{
			Value  = 'Using'
			Scope  = $VSScript
			Option = $VOReadOnly
		}
		VSWorkFlow = @{
			Value  = 'WorkFlow'
			Scope  = $VSScript
			Option = $VOReadOnly
		}
		VOAllScope = @{
			Value  = 'AllScope'
			Scope  = $VSScript
			Option = $VOReadOnly
		}
		VOPrivate  = @{
			Value  = 'Private'
			Scope  = $VSScript
			Option = $VOReadOnly
		}
		VONone     = @{
			Value  = 'None'
			Scope  = $VSScript
			Option = $VOReadOnly
		}
	}
}
Publish-Variables

$ML = @{
	Name = $ModuleName
	Path = $ModuleScriptRoot
}		

$MyVars = @{
	N02ReadOnlyVars = @{
		ModuleVersion  = @{
			Value  = $PSD1Data.ModuleVersion
			Scope  = $VSScript
			Option = $VOReadOnly
		}
		MajorPSVersion = @{
			Value  = [String]($PSVersionTable.PSVersion.Major)
			Scope  = $VSScript
			Option = $VOReadOnly
		}
		ModuleLoaded   = @{
			Value  = $ML
			Scope  = $VSScript
			Option = $VONone
		}
		Administrator  = @{
			Value  = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]'Administrator')
			Scope  = $VSScript
			Option = $VOReadOnly
		}
		Interactive    = @{
			Value  = [Environment]::UserInteractive
			Scope  = $VSScript
			Option = $VOReadOnly
		}
		MyCulture      = @{
			Value  = [cultureinfo]::GetCultures('Allcultures') | Where-Object -Property name -imatch (Get-Culture).name
			Scope  = $VSScript
			Option = $VOReadOnly
		}
		StrCRLF        = @{
			Value  = [string]"`r`n"
			Scope  = $VSScript
			Option = $VOReadOnly
		}
		StrCR          = @{
			Value  = [string]"`r"
			Scope  = $VSScript
			Option = $VOReadOnly
		}
		StrLF          = @{
			Value  = [string]"`n"
			Scope  = $VSScript
			Option = $VOReadOnly
		}
		DayOfWeek      = @{
			Value  = [Ordered]@{
				Monday    = 1
				Tuesday   = 2
				Wednesday = 3
				Thursday  = 4
				Friday    = 5
				Saturday  = 6
				Sunday    = 7
				1         = 'Monday'
				2         = 'Tuesday'
				3         = 'Wednesday'
				4         = 'Thursday'
				5         = 'Friday'
				6         = 'Saturday'
				7         = 'Sunday'
			}
			Scope  = $VSScript
			Option = $VOReadOnly
		}
		MonthOfYear    = @{
			Value  = [Ordered]@{
				January   = 1
				February  = 2
				March     = 3
				April     = 4
				May       = 5
				June      = 6
				July      = 7
				August    = 8
				September = 9
				October   = 10
				November  = 11
				December  = 12
				1         = 'January'
				2         = 'February'
				3         = 'March'
				4         = 'April'
				5         = 'May'
				6         = 'June'
				7         = 'July'
				8         = 'August'
				9         = 'September'
				10        = 'October'
				11        = 'November'
				12        = 'December'
			}
			Scope  = $VSScript
			Option = $VOReadOnly
		}
	}
}
Publish-Variables
$MyVars = @{
	N03OtherVars = @{
		LogFilePath            = @{
			Value  = [String]$Null
			Scope  = $VSScript
			Option = $VONone
		}
		LogLevel               = @{
			Value  = [Int]0
			Scope  = $VSScript
			Option = $VONone
		}
		LogLevelSave           = @{
			Value  = [Int]0
			Scope  = $VSScript
			Option = $VONone
		}
		MaxLogLevel            = @{
			Value  = [int]5
			Scope  = $VSScript
			Option = $VOReadOnly
		}
		LogLinePad             = @{
			Value  = [Int]5
			Scope  = $VSScript
			Option = $VONone
		}
		KeepCopies             = @{
			Value  = [int]5
			Scope  = $VSScript
			Option = $VONone
		}
		FileSize               = @{
			Value  = [int]100KB
			Scope  = $VSScript
			Option = $VONone
		}
		FileNumber             = @{
			Value  = [int]10
			Scope  = $VSScript
			Option = $VONone
		}
		FileDays               = @{
			Value  = [int]10
			Scope  = $VSScript
			Option = $VONone
		}
		Console                = @{
			Value  = $False
			Scope  = $VSScript
			Option = $VONone
		}
		EnCoding               = @{
			Value  = 'UTF8'
			Scope  = $VSScript
			Option = $VONone
		}
		WindowHeight           = @{
			Value  = [int]0
			Scope  = $VSScript
			Option = $VONone
		}
		WindowWidth            = @{
			Value  = [int]0
			Scope  = $VSScript
			Option = $VONone
		}
		IsConsole              = @{
			Value  = $False
			Scope  = $VSScript
			Option = $VONone
		}
		MyInitialCallStack     = @{
			Value  = $Null
			Scope  = $VSScript
			Option = $VONone
		}
		MyInitialCallingScript = @{
			Value  = $Null
			Scope  = $VSScript
			Option = $VONone
		}
		FTraceInternalCall     = @{
			Value  = $False
			Scope  = $VSScript
			Option = $VONone
		}
		FTraceAllCalls         = @{
			Value  = $False
			Scope  = $VSScript
			Option = $VONone
		}
		FTLogFilPath           = @{
			Value  = $Null
			Scope  = $VSScript
			Option = $VONone
		}
		FTrace                 = @{
			Value  = $False
			Scope  = $VSScript
			Option = $VONone
		}
		StrContinue            = @{
			Value  = 'Continue'
			Scope  = $VSScript
			Option = $VONone
		}
		StrSilentlyContinue    = @{
			Value  = 'SilentlyContinue'
			Scope  = $VSScript
			Option = $VONone
		}
		StrInquire             = @{
			Value  = 'Inquire'
			Scope  = $VSScript
			Option = $VONone
		}
		StrStop                = @{
			Value  = 'Stop'
			Scope  = $VSScript
			Option = $VONone
		}
		StrVerbose             = @{
			Value  = 'Verbose'
			Scope  = $VSScript
			Option = $VONone
		}
		StrExtPS1             = @{
			Value  = '.ps1'
			Scope  = $VSScript
			Option = $VONone
		}
		StrExtZip             = @{
			Value  = '.zip'
			Scope  = $VSScript
			Option = $VONone
		}
	}
}
Publish-Variables
$MyVars = @{
	N09Finalise = @{
		DefineVariables         = @{
			Value  = $True
			Scope  = $VSScript
			Option = $VOReadOnly
			Use    = 'Common'
		}
		RootServerAddresses    = @{
			Value  = ( (. (Join-Path -Path $ModuleScriptRoot -ChildPath 'Helpers\Get-RootHints.ps1')).RootServerAddresses )
			Scope  = $VSScript
			Option = $VONone
		}
		QtypeMap                = @{
			Value  = . (Join-Path -Path $ModuleScriptRoot -ChildPath 'Helpers\Add-ReverseMapEntries.ps1') -Map ([ordered]@{
					# Core DNS types
					A          = 1
					NS         = 2
					CNAME      = 5
					SOA        = 6
					WKS        = 11    # Well-known services (legacy)
					PTR        = 12
					HINFO      = 13    # Host info
					MX         = 15
					TXT        = 16
					RP         = 17    # Responsible person
					AFSDB      = 18    # AFS database
					LOC        = 29    # Geographic location
					AAAA       = 28
					SRV        = 33
					NAPTR      = 35
					DNAME      = 39
					# DNSSEC types
					DS         = 43
					SSHFP      = 44
					RRSIG      = 46
					NSEC       = 47
					DNSKEY     = 48
					NSEC3      = 50
					NSEC3PARAM = 51
					TLSA       = 52
					SMIMEA     = 53
					CDS        = 59    # Child DS
					CDNSKEY    = 60    # Child DNSKEY
					# Service binding
					SVCB       = 64
					HTTPS      = 65
					# Email (legacy SPF)
					SPF        = 99    # Deprecated, use TXT
					# Transaction/Transfer
					TKEY       = 249   # Key exchange for TSIG
					TSIG       = 250   # Transaction signature
					IXFR       = 251   # Incremental zone transfer
					AXFR       = 252   # Full zone transfer
					ANY        = 255   # Request all types
					CAA        = 257
			})
			Scope  = $VSScript
			Option = $VONone
		}
		DnsClassMap             = @{
			Value  = . (Join-Path -Path $ModuleScriptRoot -ChildPath 'Helpers\Add-ReverseMapEntries.ps1') -Map ([ordered]@{
					IN   = 1
					CS   = 2
					CH   = 3
					HS   = 4
					NONE = 254
					ANY  = 255
			})
			Scope  = $VSScript
			Option = $VONone
		}
		DnssecAlgorithmMap      = @{
			Value  = . (Join-Path -Path $ModuleScriptRoot -ChildPath 'Helpers\Add-ReverseMapEntries.ps1') -Map ([ordered]@{
					RSAMD5             = 1
					DH                 = 2
					DSA                = 3
					ECC                = 4
					RSASHA1            = 5
					DSA_NSEC3_SHA1     = 6
					RSASHA1_NSEC3_SHA1 = 7
					RSASHA256          = 8
					RSASHA512          = 10
					ECC_GOST           = 12
					ECDSAP256SHA256    = 13
					ECDSAP384SHA384    = 14
					ED25519            = 15
					ED448              = 16
					INDIRECT           = 252
					PRIVATEDNS         = 253
					PRIVATEOID         = 254
			})
			Scope  = $VSScript
			Option = $VONone
		}
		DnssecDigestMap         = @{
			Value  = . (Join-Path -Path $ModuleScriptRoot -ChildPath 'Helpers\Add-ReverseMapEntries.ps1') -Map ([ordered]@{
					SHA1   = 1
					SHA256 = 2
					GOST   = 3
					SHA384 = 4
			})
			Scope  = $VSScript
			Option = $VONone
		}
		RcodeMap                = @{
			Value  = . (Join-Path -Path $ModuleScriptRoot -ChildPath 'Helpers\Add-ReverseMapEntries.ps1') -Map ([ordered]@{
				NoError          = 0
				FormErr          = 1
				ServFail         = 2
				NXDomain         = 3
				NotImp           = 4
				Refused          = 5
				YXDomain         = 6
				YXRRSet          = 7
				NXRRSet          = 8
				NotAuth          = 9
				NotZone          = 10
				BADVERS_BADSIG   = 16
				BADKEY           = 17
				BADTIME          = 18
				BADMODE          = 19
				BADNAME          = 20
				BADALG           = 21
				BADTRUNC         = 22
				BADCOOKIE        = 23
			})
			Scope  = $VSScript
			Option = $VONone
		}
		TypeCoveredMap          = @{
			Value  = . (Join-Path -Path $ModuleScriptRoot -ChildPath 'Helpers\Add-ReverseMapEntries.ps1') -Map ([ordered]@{
				A          = 1
				NS         = 2
				CNAME      = 5
				SOA        = 6
				WKS        = 11
				PTR        = 12
				HINFO      = 13
				MX         = 15
				TXT        = 16
				RP         = 17
				AFSDB      = 18
				AAAA       = 28
				LOC        = 29
				SRV        = 33
				NAPTR      = 35
				DNAME      = 39
				DS         = 43
				SSHFP      = 44
				RRSIG      = 46
				NSEC       = 47
				DNSKEY     = 48
				NSEC3      = 50
				NSEC3PARAM = 51
				TLSA       = 52
				SMIMEA     = 53
				CDS        = 59
				CDNSKEY    = 60
				SVCB       = 64
				HTTPS      = 65
				SPF        = 99
				TKEY       = 249
				TSIG       = 250
				IXFR       = 251
				AXFR       = 252
				ANY        = 255
				CAA        = 257
			})
			Scope  = $VSScript
			Option = $VONone
		}
		EdnsOptionMap           = @{
			Value  = . (Join-Path -Path $ModuleScriptRoot -ChildPath 'Helpers\Add-ReverseMapEntries.ps1') -Map ([ordered]@{
				0     = 'Reserved'
				1     = 'LLQ'
				2     = 'UL'
				3     = 'NSID'
				4     = 'DAU'
				5     = 'DHU'
				6     = 'N3U'
				7     = 'ClientSubnet'
				8     = 'Expire'
				9     = 'Cookie'
				10    = 'TcpKeepalive'
				11    = 'Padding'
				12    = 'Chain'
				13    = 'EdnsKeyTag'
				14    = 'ExtendedDnsError'
				15    = 'EdnsClientTag'
				16    = 'EdnsServerTag'
				26946 = 'DeviceID'
			})
			Scope  = $VSScript
			Option = $VONone
		}
		# DNS Header Flags (bit masks)
		DnsHeaderFlagsMap       = @{
			Value  = [ordered]@{
				QR = 0x8000  # Query/Response
				AA = 0x0400  # Authoritative Answer
				TC = 0x0200  # Truncated
				RD = 0x0100  # Recursion Desired
				RA = 0x0080  # Recursion Available
				Z  = 0x0040  # Reserved (must be zero)
				AD = 0x0020  # Authenticated Data (DNSSEC)
				CD = 0x0010  # Checking Disabled (DNSSEC)
			}
			Scope  = $VSScript
			Option = $VONone
		}
		# DNS OpCode
		DnsOpCodeMap            = @{
			Value  = . (Join-Path -Path $ModuleScriptRoot -ChildPath 'Helpers\Add-ReverseMapEntries.ps1') -Map ([ordered]@{
				QUERY  = 0
				IQUERY = 1
				STATUS = 2
				NOTIFY = 4
				UPDATE = 5
			})
			Scope  = $VSScript
			Option = $VONone
		}
		# DNSKEY Flags (bit masks for SEP/KSK identification)
		DnsKeyFlagsMap          = @{
			Value  = [ordered]@{
				ZONE   = 0x0100  # Zone Key flag (bit 7)
				REVOKE = 0x0080  # Revoke flag (bit 8)
				SEP    = 0x0001  # Secure Entry Point (bit 15) - indicates KSK
			}
			Scope  = $VSScript
			Option = $VONone
		}
		# NSEC3 Flags
		Nsec3FlagsMap           = @{
			Value  = [ordered]@{
				OptOut = 0x01
			}
			Scope  = $VSScript
			Option = $VONone
		}
		# TLSA Certificate Usage
		TlsaUsageMap            = @{
			Value  = . (Join-Path -Path $ModuleScriptRoot -ChildPath 'Helpers\Add-ReverseMapEntries.ps1') -Map ([ordered]@{
				PKIX_TA = 0  # CA constraint
				PKIX_EE = 1  # Service certificate constraint
				DANE_TA = 2  # Trust anchor assertion
				DANE_EE = 3  # Domain-issued certificate
			})
			Scope  = $VSScript
			Option = $VONone
		}
		# TLSA Selector
		TlsaSelectorMap         = @{
			Value  = . (Join-Path -Path $ModuleScriptRoot -ChildPath 'Helpers\Add-ReverseMapEntries.ps1') -Map ([ordered]@{
				FullCert = 0  # Full certificate
				SPKI     = 1  # SubjectPublicKeyInfo
			})
			Scope  = $VSScript
			Option = $VONone
		}
		# TLSA Matching Type
		TlsaMatchingTypeMap     = @{
			Value  = . (Join-Path -Path $ModuleScriptRoot -ChildPath 'Helpers\Add-ReverseMapEntries.ps1') -Map ([ordered]@{
				Exact  = 0
				SHA256 = 1
				SHA512 = 2
			})
			Scope  = $VSScript
			Option = $VONone
		}
		# SSHFP Algorithm
		SshfpAlgorithmMap       = @{
			Value  = . (Join-Path -Path $ModuleScriptRoot -ChildPath 'Helpers\Add-ReverseMapEntries.ps1') -Map ([ordered]@{
				RSA     = 1
				DSA     = 2
				ECDSA   = 3
				ED25519 = 4
				ED448   = 6
			})
			Scope  = $VSScript
			Option = $VONone
		}
		# SSHFP Fingerprint Type
		SshfpFingerprintTypeMap = @{
			Value  = . (Join-Path -Path $ModuleScriptRoot -ChildPath 'Helpers\Add-ReverseMapEntries.ps1') -Map ([ordered]@{
				SHA1   = 1
				SHA256 = 2
			})
			Scope  = $VSScript
			Option = $VONone
		}
		TrustAnchorsInitialized = @{
			Value  = ( . (Join-Path -Path $PSScriptRoot -ChildPath 'Initialize-DnssecTrustAnchors.ps1') )
			Scope  = $VSScript
			Option = $VONone
		}
	}
}
Publish-Variables
