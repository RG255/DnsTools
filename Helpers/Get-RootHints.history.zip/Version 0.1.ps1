Set-Variable -Name RHFileName -Value 'RootHints.conf'
# URI to obtain the root hints file
Set-Variable -Name URI_RH -Value 'https://www.internic.net/domain/named.root'
			Try
			{
				# Obtain the Root Hints list of servers
				$Script:RHDataIn = -join [char[]](Invoke-WebRequest -Uri ('{0}' -f $URI_RH) -UseBasicParsing).Content
				#if ("$FileList" -notmatch "$RHFileName")
				#{$FileList += $RHFileName}
			}
			Catch
			{
				Write-Warning -Message ('Unable to obtain root hints from: [{0}]' -f $URI_RH)
				$Script:MyError = $True
				Get-MyErrors -Return
			}
$Script:RHDataIn
# Initialise storage
$Script:RootServers = @()
$Script:RootServerMap = @{}

# Split into lines
$lines = $Script:RHDataIn -split "`n" | ForEach-Object { $_.Trim() }

foreach ($line in $lines) {

    # Skip comments and blanks
    if ($line -match '^\s*;') { continue }
    if ($line -eq '') { continue }

    # -----------------------------
    # Match NS records for the root
    # Example:
    # .   3600000   NS   A.ROOT-SERVERS.NET.
    # -----------------------------
    if ($line -match '^\.\s+\d+\s+NS\s+([A-Za-z0-9\.\-]+)\.?$') {

        $hn = $Matches[1].ToUpper() + '.'

        $entry = [ordered]@{
            Name     = '.'
            HostName = $hn
            IPv4     = $null
            IPv6     = $null
        }

        $Script:RootServers += $entry
        $Script:RootServerMap[$hn] = $entry
        continue
    }

    # -----------------------------
    # Match IPv4 glue
    # Example:
    # A.ROOT-SERVERS.NET.  3600000  A  198.41.0.4
    # -----------------------------
    if ($line -match '^([A-Za-z0-9\.\-]+)\.?\s+\d+\s+A\s+([0-9\.]+)$') {

        $hn   = $Matches[1].ToUpper() + '.'
        $addr = $Matches[2]

        if ($Script:RootServerMap.ContainsKey($hn)) {
            $Script:RootServerMap[$hn].IPv4 = $addr
        }
        continue
    }

    # -----------------------------
    # Match IPv6 glue
    # Example:
    # A.ROOT-SERVERS.NET.  3600000  AAAA  2001:503:ba3e::2:30
    # -----------------------------
    if ($line -match '^([A-Za-z0-9\.\-]+)\.?\s+\d+\s+AAAA\s+([0-9A-Fa-f:]+)$') {

        $hn   = $Matches[1].ToUpper() + '.'
        $addr = $Matches[2]

        if ($Script:RootServerMap.ContainsKey($hn)) {
            $Script:RootServerMap[$hn].IPv6 = $addr
        }
        continue
    }
}

# Build flat list of usable IPs
$Script:RootServerAddresses =
    $Script:RootServers |
    ForEach-Object { @($_.IPv4, $_.IPv6) | Where-Object { $_ } }


$Script:RootServers
$Script:RootServerAddresses