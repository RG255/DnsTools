# Tests/DnsSecTools.Tests.ps1
# Run with: Invoke-Pester

using module 'D:\PowerShellScripts\RawDns\0.3\DnsSecTools.psd1'

Describe 'DnsSecTools Module' {
    BeforeAll {
        Add-DnssecTrustAnchor `
            -Zone '.' `
            -KeyTag 20326 `
            -Algorithm 8 `
            -DigestType 2 `
            -DigestHex 'e06d44b80b8f1d21f0f3e0d1d9c1c5b56a2f0e9f0e3c2c5c5e2e0f0f0c5b5a5c'
    }
}

	Describe "DnsBinaryReader and DNS parsing" {

		It "Parses DNS header correctly" {
    $bytes = [byte[]](0x12,0x34,0x01,0x00,0x00,0x01,0x00,0x02,0x00,0x03,0x00,0x04)
    $reader = [DnsBinaryReader]::new($bytes)
    $header = [DnsHeader]::Parse($reader)

    $header.Id      | Should -Be 0x1234
    $header.Flags   | Should -Be 0x0100
    $header.QdCount | Should -Be 1
    $header.AnCount | Should -Be 2
    $header.NsCount | Should -Be 3
    $header.ArCount | Should -Be 4
}


		It "Encodes and decodes a simple query" {
				$packet = New-DnsQueryPacket -Name "example.com" -Type 1
				$parsed = [DnsPacket]::Parse($packet)
				$parsed.Questions[0].Name | Should -Be "example.com"
				$parsed.Questions[0].Type | Should -Be 1
		}

		It "Parses DNSKEY RDATA" {
				$flags = 256
				$protocol = 3
				$algorithm = 8
				$pub = [byte[]](1,2,3,4,5)

				$w = [DnsBinaryWriter]::new()
				$w.WriteUInt16BE([uint16]$flags)
				$w.WriteUInt8([byte]$protocol)
				$w.WriteUInt8([byte]$algorithm)
				$w.WriteBytes($pub)
				$rdata = $w.ToArray()

				$record = Parse-DNSKEY -RData $rdata
				$record.Flags     | Should -Be $flags
				$record.Protocol  | Should -Be $protocol
				$record.Algorithm | Should -Be $algorithm
				$record.PublicKey | Should -HaveCount 5
		}

		It "Parses NSEC type bitmap" {
				$w = [DnsBinaryWriter]::new()
				$w.WriteName("next.example.com")
				$w.WriteUInt8(0)
				$w.WriteUInt8(1)
				$w.WriteUInt8(0x10000000)
        $rdata = $w.ToArray()

        $nsec = Parse-NSEC -RData $rdata
        $nsec.NextDomainName | Should -Be "next.example.com"
        $nsec.Types          | Should -Contain 1
    }

	Context 'Module Loading' {
		It 'Should import without errors' {
			{Import-Module ('{0}/../DnsSecTools.psd1' -f $PSScriptRoot) -Force} | Should -Not -Throw
		}

		It 'Should expose expected functions' {
			(Get-Command Test-DnssecName).Name | Should -Be 'Test-DnssecName'
			(Get-Command Resolve-DnssecName).Name | Should -Be 'Resolve-DnssecName'
			(Get-Command Parse-DnsPacket).Name | Should -Be 'Parse-DnsPacket'
		}
	}
	Context 'DNS Header Parsing' {
		It 'Parses a valid DNS header' {
			$bytes = [byte[]](0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00)
			$header = Parse-DnsHeader -Packet $bytes
			$header.ID      | Should -Be 0x1234
			$header.Flags   | Should -Be 0x0100
			$header.QDCount | Should -Be 1
		}
	}

	Context 'DNS Question Parsing' {
		It 'Parses a simple question' {
			# Query: example.com A
			$packet = New-DnsQueryPacket -Name 'example.com' -Type 1
			$offset = 12
			$q = Parse-DnsQuestion -Packet $packet -Offset ([ref]$offset)
			$q.Name.Text | Should -Be 'example.com'
			$q.Type      | Should -Be 1
			$q.Class     | Should -Be 1
		}
	}

	Context 'RDATA Parsing' {
		It 'Parses A record' {
			$r = Parse-A -RData ([byte[]](1, 2, 3, 4)) -Packet $null -Offset 0
			$r.Address | Should -Be '1.2.3.4'
		}

		It 'Parses TXT record' {
			$raw = [byte[]](3, 0x66, 0x6f, 0x6f) # "foo"
			$r = Parse-TXT -RData $raw -Packet $null -Offset 0
			$r.Strings[0] | Should -Be 'foo'
		}

		It 'Parses DNSKEY' {
			$raw = [byte[]](0x01, 0x00, 0x03, 0x08, 0xAA, 0xBB, 0xCC)
			$r = Parse-DNSKEY -RData $raw -Packet $null -Offset 0
			$r.Flags      | Should -Be 256
			$r.Protocol   | Should -Be 3
			$r.Algorithm  | Should -Be 8
			$r.PublicKey  | Should -HaveCount 3
		}
	}

	Context 'DNSSEC Cryptographic Validation' {
		It 'Rejects expired RRSIG' {
			$rrsig = [DnsRrsigRecord]::new(
				[byte[]](0, 1, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
				[byte[]]::new(0),
				0
			)
			$rrsig.Expiration = 1
			Test-DnssecTimeWindow -Rrsig $rrsig | Should -BeFalse
		}
	}

	Context 'DS → DNSKEY Validation' {
		It 'Rejects DNSKEY that does not match DS' {
			$ds = [DnsDsRecord]::new([byte[]](0x00, 0x01, 8, 2, 0xAA, 0xBB))
			$dnskey = [DnsDnskeyRecord]::new([byte[]](0x01, 0x00, 3, 8, 0xCC, 0xDD))

			$result = Test-DnssecDsForDnskey `
			-DsRrset @([pscustomobject]@{
					RData = $ds
			}) `
			-DnskeyRrset @([pscustomobject]@{
					RData = $dnskey
			}) `
			-ChildZoneName 'example.com'

			$result.Valid | Should -BeFalse
		}
	}

	Context 'End-to-End DNSSEC Resolution' {
		It 'Validates a known DNSSEC-signed domain' -Tag 'Online' {
			$result = Resolve-DnssecName -Name 'cloudflare.com' -Type 1
			$result.Valid | Should -BeTrue
		}

		It 'Detects bogus DNSSEC' -Tag 'Online' {
			# dnssec-failed.org is intentionally broken
			$result = Resolve-DnssecName -Name 'dnssec-failed.org' -Type 1
			$result.Valid | Should -BeFalse
		}
	}
}

