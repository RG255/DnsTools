# Tests/DnsSecTools.Tests.ps1
# Run with: Invoke-Pester

# IMPORTANT:
# using module must be the first real statement in the file.
using module 'D:\PowerShellScripts\RawDns\0.3\DnsSecTools.psd1'


# ------------------------------------------------------------
# DNSSEC Trust Anchor Setup
# ------------------------------------------------------------
Describe 'DnsSecTools Module' {

    BeforeAll {
        Add-DnssecTrustAnchor `
            -Zone '.' `
            -KeyTag 20326 `
            -Algorithm 8 `
            -DigestType 2 `
            -DigestHex 'e06d44b80b8f1d21f0f3e0d1d9c1c5b56a2f0e9f0e3c2c5c5e2e0f0f0c5b5a5c'
    }


    # ------------------------------------------------------------
    # Binary Reader / Writer Tests
    # ------------------------------------------------------------
    Describe "DnsBinaryReader and DNS parsing" {

        It "Parses DNS header correctly" {
            $bytes = [byte[]](0x12,0x34,0x01,0x00,0x00,0x01,0x00,0x02,0x00,0x03,0x00,0x04)
            $reader = [DnsBinaryReader]::new($bytes)
            $header = [DnsHeader]::Parse($reader)

            $header.Id      | Should -Be 0x1234
            $header.Flags   | Should -Be 0x0100
            $header.QdCount | Should -Be 1
            $header.AnCount | Should -Be 2
            $header.NsCount | Should -Be 3
            $header.ArCount | Should -Be 4
        }


        It "Encodes and decodes a simple query" {
            # NOTE:
            # Your New-DnsQueryPacket includes EDNS by default.
            # Your parser must correctly detect OPT (TYPE=41).
            # After fixing EDNS flags to 16 bits, this test will pass.

            $packet = New-DnsQueryPacket -Name "example.com" -Type 1
            $parsed = [DnsPacket]::Parse($packet)

            $parsed.Questions.Count | Should -Be 1
            $parsed.Questions[0].Name | Should -Be "example.com"
            $parsed.Questions[0].Type | Should -Be 1
        }


        It "Parses DNSKEY RDATA" {
            $flags = 256
            $protocol = 3
            $algorithm = 8
            $pub = [byte[]](1,2,3,4,5)

            $w = [DnsBinaryWriter]::new()
            $w.WriteUInt16BE([uint16]$flags)
            $w.WriteUInt8([byte]$protocol)
            $w.WriteUInt8([byte]$algorithm)
            $w.WriteBytes($pub)
            $rdata = $w.ToArray()

            $record = Parse-DNSKEY -RData $rdata
            $record.Flags     | Should -Be $flags
            $record.Protocol  | Should -Be $protocol
            $record.Algorithm | Should -Be $algorithm
            $record.PublicKey | Should -HaveCount 5
        }


It "Parses NSEC type bitmap" {

    #
    # Build NSEC RDATA
    #
    $rdataWriter = [DnsBinaryWriter]::new()
    $rdataWriter.WriteName("next.example.com")
    $rdataWriter.WriteUInt8(0)      # window
    $rdataWriter.WriteUInt8(1)      # bitmap length
    $rdataWriter.WriteUInt8(0x80)   # bitmap byte (type 1)
    $rdata = $rdataWriter.ToArray()

    #
    # Build a full DNS packet with:
    # - header
    # - 0 questions
    # - 1 answer (our NSEC)
    #
    $pkt = [DnsBinaryWriter]::new()

    # Header: ID=0, Flags=0, QD=0, AN=1, NS=0, AR=0
    $pkt.WriteUInt16BE(0)   # ID
    $pkt.WriteUInt16BE(0)   # Flags
    $pkt.WriteUInt16BE(0)   # QDCOUNT
    $pkt.WriteUInt16BE(1)   # ANCOUNT
    $pkt.WriteUInt16BE(0)   # NSCOUNT
    $pkt.WriteUInt16BE(0)   # ARCOUNT

    # Answer RR
    $pkt.WriteName("example.com")
    $pkt.WriteUInt16BE(47)              # TYPE = NSEC
    $pkt.WriteUInt16BE(1)               # CLASS = IN
    $pkt.WriteUInt32BE(3600)            # TTL
    $pkt.WriteUInt16BE($rdata.Length)   # RDLENGTH
    $pkt.WriteBytes($rdata)             # RDATA

    $packetBytes = $pkt.ToArray()

    #
    # Parse the packet
    #
    $packet = [DnsPacket]::Parse($packetBytes)
    $rr = $packet.Answers[0]
    $nsec = $rr.RDataObject

    #
    # Assertions
    #
    $nsec.NextDomainName | Should -Be "next.example.com"
    $nsec.Types          | Should -Contain 1
}



    }


    # ------------------------------------------------------------
    # Module Loading Tests
    # ------------------------------------------------------------
    Context 'Module Loading' {

        It 'Should import without errors' {
            { Import-Module ('{0}/../DnsSecTools.psd1' -f $PSScriptRoot) -Force } | Should -Not -Throw
        }

        It 'Should expose expected functions' {
            (Get-Command Test-DnssecName).Name | Should -Be 'Test-DnssecName'
            (Get-Command Resolve-DnssecName).Name | Should -Be 'Resolve-DnssecName'
            (Get-Command Parse-DnsPacket).Name | Should -Be 'Parse-DnsPacket'
        }
    }


    # ------------------------------------------------------------
    # DNS Header Parsing
    # ------------------------------------------------------------
    Context 'DNS Header Parsing' {

        It 'Parses a valid DNS header' {
            $bytes = [byte[]](0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00)
            $header = Parse-DnsHeader -Packet $bytes
            $header.ID      | Should -Be 0x1234
            $header.Flags   | Should -Be 0x0100
            $header.QDCount | Should -Be 1
        }
    }


    # ------------------------------------------------------------
    # DNS Question Parsing
    # ------------------------------------------------------------
    Context 'DNS Question Parsing' {

        It 'Parses a simple question' {
            $packet = New-DnsQueryPacket -Name 'example.com' -Type 1
            $offset = 12
            $q = Parse-DnsQuestion -Packet $packet -Offset ([ref]$offset)

           $q.Name  | Should -Be 'example.com'
$q.Type  | Should -Be 1
$q.Class | Should -Be 1

        }
    }


    # ------------------------------------------------------------
    # RDATA Parsing
    # ------------------------------------------------------------
    Context 'RDATA Parsing' {

        It 'Parses A record' {
            $r = Parse-A -RData ([byte[]](1, 2, 3, 4)) -Packet $null -Offset 0
            $r.Address | Should -Be '1.2.3.4'
        }

        It 'Parses TXT record' {
            $raw = [byte[]](3, 0x66, 0x6f, 0x6f)
            $r = Parse-TXT -RData $raw -Packet $null -Offset 0
            $r.Strings[0] | Should -Be 'foo'
        }

        It 'Parses DNSKEY' {
            $raw = [byte[]](0x01, 0x00, 0x03, 0x08, 0xAA, 0xBB, 0xCC)
            $r = Parse-DNSKEY -RData $raw -Packet $null -Offset 0
            $r.Flags      | Should -Be 256
            $r.Protocol   | Should -Be 3
            $r.Algorithm  | Should -Be 8
            $r.PublicKey  | Should -HaveCount 3
        }
    }


    # ------------------------------------------------------------
    # DNSSEC Crypto Tests
    # ------------------------------------------------------------
    Context 'DNSSEC Cryptographic Validation' {

        It 'Rejects expired RRSIG' {
    $rrsig = [DnsRrsigRecord]::new(
        1,          # TypeCovered
        8,          # Algorithm
        0,          # Labels
        3600,       # OriginalTtl
        1,          # Expiration
        0,          # Inception
        0,          # KeyTag
        '.',        # SignerName
        [byte[]]@() # Signature
    )

    Test-DnssecTimeWindow -Rrsig $rrsig | Should -BeFalse
}

    }


    # ------------------------------------------------------------
    # DS → DNSKEY Validation
    # ------------------------------------------------------------
    Context 'DS → DNSKEY Validation' {

        It 'Rejects DNSKEY that does not match DS' {
    # DS: KeyTag 1, Algorithm 8, DigestType 2, Digest = AABB
    $ds = [DnsDsRecord]::new(
        1,                     # KeyTag
        [byte]8,               # Algorithm
        [byte]2,               # DigestType
        [byte[]](0xAA, 0xBB)   # Digest
    )

    # DNSKEY: Flags 256, Protocol 3, Algorithm 8, PublicKey = CCDD
    $dnskey = [DnsDnskeyRecord]::new(
        256,                   # Flags
        [byte]3,               # Protocol
        [byte]8,               # Algorithm
        [byte[]](0xCC, 0xDD)   # PublicKey
    )

    $result = Test-DnssecDsForDnskey `
        -DsRrset @([pscustomobject]@{ RData = $ds }) `
        -DnskeyRrset @([pscustomobject]@{ RData = $dnskey }) `
        -ChildZoneName 'example.com'

    $result.Valid | Should -BeFalse
}

    }


    # ------------------------------------------------------------
    # End-to-End DNSSEC Resolution (Online)
    # ------------------------------------------------------------
    Context 'End-to-End DNSSEC Resolution' {

        It 'Validates a known DNSSEC-signed domain' -Tag 'Online' {
            $result = Resolve-DnssecName -Name 'cloudflare.com' -Type 1
            $result.Valid | Should -BeTrue
        }

        It 'Detects bogus DNSSEC' -Tag 'Online' {
            $result = Resolve-DnssecName -Name 'dnssec-failed.org' -Type 1
            $result.Valid | Should -BeFalse
        }
    }
}
