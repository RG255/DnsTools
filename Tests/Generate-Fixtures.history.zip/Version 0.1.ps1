param(
    [string]$OutputPath = (Join-Path $PSScriptRoot 'Fixtures')
)

if (-not (Test-Path $OutputPath)) {
    New-Item -ItemType Directory -Path $OutputPath | Out-Null
}

function Write-Fixture {
    param(
        [string]$Name,
        [byte[]]$Bytes
    )

    $path = Join-Path $OutputPath $Name
    [IO.File]::WriteAllBytes($path, $Bytes)
    Write-Host "Wrote $Name ($($Bytes.Length) bytes)"
}

# Helper: build a minimal A record response
function New-SimpleAResponse {
    param(
        [string]$Name,
        [string]$Address
    )

    $hdr = [DnsHeader]::new(
        0x1234,
        0x8180,   # QR=1, RD=1, RA=1, NOERROR
        1, 1, 0, 0
    )

    $q = [DnsQuestion]::new($Name, 1, 1)

    $ipBytes = [System.Net.IPAddress]::Parse($Address).GetAddressBytes()
    $rr = [DnsResourceRecord]::new(
        $Name,
        1,
        1,
        300,
        $ipBytes,
        [DnsARecord]::Parse($ipBytes)
    )

    $pkt = [DnsPacket]::new()
    $pkt.Header = $hdr
    $pkt.Questions.Add($q)
    $pkt.Answers.Add($rr)

    return $pkt.ToArray()
}

# ============================================================
# 1. DoT Fixtures
# ============================================================

# dot-simple-response.bin
$resp = New-SimpleAResponse -Name 'example.com' -Address '192.0.2.10'
Write-Fixture -Name 'dot-simple-response.bin' -Bytes $resp

# dot-large-response.bin (multiple answers)
$pkt = [DnsPacket]::new()
$pkt.Header = [DnsHeader]::new(0x2222, 0x8180, 1, 5, 0, 0)
$pkt.Questions.Add([DnsQuestion]::new('large.example.com', 1, 1))

for ($i = 1; $i -le 5; $i++) {
    $ip = "203.0.113.$i"
    $bytes = [System.Net.IPAddress]::Parse($ip).GetAddressBytes()
    $rr = [DnsResourceRecord]::new(
        'large.example.com',
        1,
        1,
        300,
        $bytes,
        [DnsARecord]::Parse($bytes)
    )
    $pkt.Answers.Add($rr)
}

Write-Fixture -Name 'dot-large-response.bin' -Bytes ($pkt.ToArray())

# ============================================================
# 2. DoH Fixtures
# ============================================================

# doh-simple-response.bin
Write-Fixture -Name 'doh-simple-response.bin' -Bytes (New-SimpleAResponse -Name 'example.com' -Address '192.0.2.20')

# doh-large-response.bin
Write-Fixture -Name 'doh-large-response.bin' -Bytes ($pkt.ToArray())

# ============================================================
# 3. DNSSEC Canonicalization Fixtures
# ============================================================

# canonical-name-wire.bin
$nameWire = Get-DnssecCanonicalNameWire -Name 'www.Example.COM'
Write-Fixture -Name 'canonical-name-wire.bin' -Bytes $nameWire

# canonical-rrset.bin
$rr1 = [DnsResourceRecord]::new('a.example', 1, 1, 300, ([byte[]](1,2,3,4)), $null)
$rr2 = [DnsResourceRecord]::new('a.example', 1, 1, 300, ([byte[]](1,2,3,5)), $null)
$rrset = @($rr1, $rr2)
$sorted = Get-DnssecCanonicalRrsetData -Rrset $rrset
$bytes = New-Object System.Collections.Generic.List[byte]
foreach ($rec in $sorted) { $bytes.AddRange($rec.RdataWire) }
Write-Fixture -Name 'canonical-rrset.bin' -Bytes ($bytes.ToArray())

# signed-data.bin
$rrsig = [DnsRrsigRecord]::new(1, 8, 2, 300, 0x5F5E100, 0x5F5E000, 12345, 'example.com', ([byte[]](1..32)))
$sd = Get-DnssecSignedData -Rrsig $rrsig -Rrset $rrset
Write-Fixture -Name 'signed-data.bin' -Bytes $sd

# ============================================================
# 4. Resolver Edge Case Fixtures
# ============================================================

# referral-broken-glue.bin
$pkt = [DnsPacket]::new()
$pkt.Header = [DnsHeader]::new(0x3333, 0x8180, 1, 0, 1, 1)
$pkt.Questions.Add([DnsQuestion]::new('broken.example', 1, 1))

# NS record
$nsRdata = (New-Object DnsBinaryWriter).WriteName('ns1.broken.example'); $nsRdata = $null
$w = [DnsBinaryWriter]::new(); $w.WriteName('ns1.broken.example'); $nsRdata = $w.ToArray()
$ns = [DnsResourceRecord]::new('broken.example', 2, 1, 300, $nsRdata, [DnsNsRecord]::new('ns1.broken.example'))
$pkt.Authority.Add($ns)

# Broken glue: wrong name
$badGlue = [DnsResourceRecord]::new('wrong.example', 1, 1, 300, ([byte[]](10,0,0,1)), $null)
$pkt.Additional.Add($badGlue)

Write-Fixture -Name 'referral-broken-glue.bin' -Bytes ($pkt.ToArray())

# referral-mismatched-ns.bin
$pkt = [DnsPacket]::new()
$pkt.Header = [DnsHeader]::new(0x4444, 0x8180, 1, 0, 1, 0)
$pkt.Questions.Add([DnsQuestion]::new('mismatch.example', 1, 1))
$w = [DnsBinaryWriter]::new(); $w.WriteName('ns99.example'); $nsRdata = $w.ToArray()
$pkt.Authority.Add([DnsResourceRecord]::new('mismatch.example', 2, 1, 300, $nsRdata, [DnsNsRecord]::new('ns99.example')))
Write-Fixture -Name 'referral-mismatched-ns.bin' -Bytes ($pkt.ToArray())

# referral-empty-authority.bin
$pkt = [DnsPacket]::new()
$pkt.Header = [DnsHeader]::new(0x5555, 0x8180, 1, 0, 0, 0)
$pkt.Questions.Add([DnsQuestion]::new('empty.example', 1, 1))
Write-Fixture -Name 'referral-empty-authority.bin' -Bytes ($pkt.ToArray())

# referral-cyclic-ns.bin
$pkt = [DnsPacket]::new()
$pkt.Header = [DnsHeader]::new(0x6666, 0x8180, 1, 0, 1, 0)
$pkt.Questions.Add([DnsQuestion]::new('cycle.example', 1, 1))
$w = [DnsBinaryWriter]::new(); $w.WriteName('cycle.example'); $nsRdata = $w.ToArray()
$pkt.Authority.Add([DnsResourceRecord]::new('cycle.example', 2, 1, 300, $nsRdata, [DnsNsRecord]::new('cycle.example')))
Write-Fixture -Name 'referral-cyclic-ns.bin' -Bytes ($pkt.ToArray())

Write-Host "Extended fixtures generated in $OutputPath"
