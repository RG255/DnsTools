@{
    RootModule        = 'InitialiseDnsToolsModule.psm1'
    ModuleVersion     = '0.4'
    GUID              = 'b7c3b8d1-4f2e-4e8e-9f5f-1c2b3d4e5f6a'
    Author            = 'Ray'
    CompanyName       = 'Ray Labs'
    Copyright         = '(c) Ray'
    Description       = 'A full DNS, DNSSEC, DoT, DoH, and iterative resolver toolkit for PowerShell.'

    PowerShellVersion = '5.1'

    FunctionsToExport = '*'
    CmdletsToExport   = @()
    VariablesToExport = @()
    AliasesToExport   = @()

    PrivateData = @{
        PSData = @{
            Tags = @(
                'DNS', 'DNSSEC', 'DoT', 'DoH',
                'Resolver', 'Networking', 'Security'
            )
            LicenseUri = 'https://opensource.org/licenses/MIT'
            ProjectUri = 'https://github.com/yourrepo'
        }
    }
}
